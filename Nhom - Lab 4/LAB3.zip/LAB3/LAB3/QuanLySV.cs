﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LAB3
{
    public partial class QuanLySV : Form
    {
        public QuanLySV()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-DT03IGN\SQLEXPRESS;Initial Catalog=QLSVNhom;Integrated Security=True");
            string qr = "SELECT MASV,HOTEN,NGAYSINH,DIACHI,MALOP FROM SINHVIEN";
            SqlDataAdapter sda = new SqlDataAdapter(qr, con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
            foreach (DataGridViewColumn dc in dataGridView1.Columns)
            {
                if (dc.Index.Equals(0))
                {
                    dc.ReadOnly = true;
                }
                else
                {
                    dc.ReadOnly = false;
                }
            }
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-DT03IGN\SQLEXPRESS;Initial Catalog=QLSVNhom;Integrated Security=True");
            string qr = "UPDATE SINHVIEN SET HOTEN = '" + dataGridView1.CurrentRow.Cells[dataGridView1.Columns["HOTEN"].Index].Value + "', NGAYSINH = '" + dataGridView1.CurrentRow.Cells[dataGridView1.Columns["NGAYSINH"].Index].Value + "', DIACHI = '" + dataGridView1.CurrentRow.Cells[dataGridView1.Columns["DIACHI"].Index].Value + "'WHERE = '" + dataGridView1.CurrentRow.Cells[dataGridView1.Columns["MASV"].Index].Value + "'";
           
            SqlCommand cmd = new SqlCommand(qr, con);

            //foreach (DataGridViewColumn dc in dataGridView1.Columns)
            //{
            //    if (dc.Index.Equals(0))
            //    {
            //        dc.ReadOnly = true;
            //    }
            //    else
            //    {
            //        dc.ReadOnly = false;
            //    }
            //}

            cmd.ExecuteNonQuery();
        }
    }
}
