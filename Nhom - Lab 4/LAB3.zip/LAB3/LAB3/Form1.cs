﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data;

namespace LAB3
{
    public partial class LoginScr : Form
    {
        public LoginScr()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-DT03IGN\SQLEXPRESS;Initial Catalog=QLSVNhom;Integrated Security=True");
            string tk = DienTenDN.Text.Trim();
            string mk = DienMK.Text.Trim();
            string qr = "SELECT TENDN,MATKHAU FROM NHANVIEN WHERE TENDN='" + tk + "' AND CONVERT(VARCHAR(MAX),MATKHAU,2)=CONVERT(VARCHAR(MAX),HASHBYTES('SHA1','" + mk + "'),2)";
            SqlDataAdapter sda = new SqlDataAdapter(qr, con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows.Count==1)
            {
                MessageBox.Show("Đăng nhập thành công");
                this.Hide();
                QuanLySV qlsv = new QuanLySV();
                qlsv.ShowDialog();
                this.Close();
            }
            else
            {
                MessageBox.Show("Đăng nhập thất bại");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void DienTenDN_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }
    }
}
